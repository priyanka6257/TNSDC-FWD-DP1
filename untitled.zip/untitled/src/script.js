// Simple form submission handling

document.getElementById('contactForm').addEventListener('submit', function(e) {

  e.preventDefault();

  const message = document.getElementById('formMessage');

  message.textContent = "Thank you! Your message has been sent.";

  message.style.color = "green";

  // Clear the form

  this.reset();

});